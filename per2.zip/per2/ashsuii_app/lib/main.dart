import 'package:flutter/material.dart';

void main(List<String> args) {
  runApp(Myapp());
}

class Myapp extends StatelessWidget {
  const Myapp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        drawer: Drawer(),
        appBar: AppBar(
          title: Text("Ashsuii App"),
          backgroundColor: Colors.deepPurple,
          foregroundColor: Colors.cyan,
          ),
        body: Center(
          child: Column(
            children: [
              Text("Ashsuii Corp."),
            ],
          )),
      ),
    );
  }
}